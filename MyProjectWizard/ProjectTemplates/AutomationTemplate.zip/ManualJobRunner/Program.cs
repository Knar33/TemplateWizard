﻿using $ClientName$.Automation;
using IdComLog.Scheduling;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $ClientName$.$safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {

            ManualJob.Run(args, new[]
            {
               new ManualJob
                {
                    Name = "print",
                    Factory = new $ClientName$.Automation.PrintJobFactory(),
                    TriggerId = $PrintTrigger$
                } ,
                new ManualJob
                {
                    Name = "shipconfirm",
                    Factory = new $ClientName$.Automation.ShipConfirmJobFactory(),
                    TriggerId = $ShipConfirmTrigger$
                },
                new ManualJob
                {
                    Name = "Import",
                    Factory = new $ClientName$.Automation.ImportJobFactory(),
                    TriggerId = $ImportTrigger$
                }
            });
        }
    }
}
