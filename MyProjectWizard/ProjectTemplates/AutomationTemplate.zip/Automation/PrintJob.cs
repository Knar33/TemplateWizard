﻿using IdComLog;
using IdComLog.$safeprojectname$;
using IdComLog.Extensions;
using IdComLog.Printing;
using IdComLog.Scheduling;
using IdComLog.Shipping;
using IdComLog.Shipping.RRD;
using IdComLog.Shipping.UPS;
using Microsoft.SqlServer.Server;
using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IdComLog.Utility;
using System.Configuration;

namespace $ClientName$.$safeprojectname$
{
    public class PrintJob : IdComLog.$safeprojectname$.PrintJob
    {
        public PrintJob(Guid clientId, OmsJobSettings settings, PrintJobSettings printSettings) : base(clientId, settings, printSettings)
        {
        }
    }
}