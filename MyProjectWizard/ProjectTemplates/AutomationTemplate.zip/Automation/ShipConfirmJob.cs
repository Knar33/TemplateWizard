﻿using IdComLog.$safeprojectname$;
using System;

namespace $ClientName$.$safeprojectname$
{
    public class ShipConfirmJob : IdComLog.$safeprojectname$.ShipConfirmJob
    {
        public ShipConfirmJob(Guid clientid, OmsJobSettings settings, ShipConfirmJobSettings importJobSettings) : base(clientid, settings, importJobSettings)
        {
        }
    }
}
