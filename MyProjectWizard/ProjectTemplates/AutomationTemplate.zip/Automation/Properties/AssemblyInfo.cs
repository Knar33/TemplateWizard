﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("VivaNaturals.$safeprojectname$")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("iD Commerce + Logistics")]
[assembly: AssemblyProduct("VivaNaturals.$safeprojectname$")]
[assembly: AssemblyCopyright("Copyright ©2017-2018, iD Commerce + Logistics")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("a8e097e0-d619-41a7-9720-a7260bc0bdf7")]

// **********************************************************************************
// We follow the semantic versioning scheme at http://semver.org/
//
// This means:
//      MAJOR version when you make incompatible API changes,
//      MINOR version when you add functionality in a backwards-compatible manner, and
//      PATCH version when you make backwards-compatible bug fixes
//
[assembly: AssemblyVersion("1.0.0")]
[assembly: AssemblyFileVersion("1.0.0")]
