﻿using IdComLog.Scheduling;
using IdComLog;
using System;
using IdComLog.$safeprojectname$;
using IdComLog.VeraCore;
using IdComLog.VeraCore.pmomsws;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace $ClientName$.$safeprojectname$
{
    public class ImportJobFactory : OmsJobFactory
    {
        protected override OmsJob CreateJob(OmsJobSettings settings)
        {
            Guid clientId = new Guid(Config.AppSettings["ClientId"]);

            OMSSoapClient omsClient = new OMSSoapClient(new System.ServiceModel.BasicHttpBinding(), new System.ServiceModel.EndpointAddress(string.Format("{0}/pmomsws/oms.asmx", ConfigurationManager.AppSettings["VeraCoreURL"])));
            omsClient.InnerChannel.OperationTimeout = new TimeSpan(0, 0, 0, 0, Int32.Parse(ConfigurationManager.AppSettings["WebRequestTimeout"]));
            AuthenticationHeader omsAuth = new AuthenticationHeader() { Username = ConfigurationManager.AppSettings["VeraCoreOMSAPIUsername"], Password = ConfigurationManager.AppSettings["VeraCoreOMSAPIPassword"] };

            ImportJobSettings importJobSettings = new ImportJobSettings()
            {
                OMSClient = omsClient,
                OMSAuth = omsAuth,
                SQLTimeout = Int32.Parse(ConfigurationManager.AppSettings["SQLTimeout"])
            };
            return new ImportJob(clientId, settings, importJobSettings);
        }
    }
}
