﻿using IdComLog;
using IdComLog.$safeprojectname$;
using IdComLog.Shipping;
using IdComLog.Shipping.UPS;
using IdComLog.Shipping.RRD;
using System;
using System.Collections.Generic;
using IdComLog.VeraCore;
using System.Configuration;
using System.Linq;

namespace $ClientName$.$safeprojectname$
{
    public class PrintJobFactory : OmsJobFactory
    {
        protected override OmsJob CreateJob(OmsJobSettings settings)
        {
            Guid clientId = new Guid(Config.AppSettings["ClientId"]);

            List<IShipper> shippers = new List<IShipper>();
            shippers.Add(new UPSShipper()
            {
                Url = Config.AppSettings["UPSWebServiceUrl"]
            });
            shippers.Add(new RRDShipper());

            List<IShippingAccount> shippingAccounts = new List<IShippingAccount>();
            shippingAccounts.Add(new UPSShippingAccount()
            {
                AccessLicenseNumber = Config.AppSettings["UPSAccessLicenseNumber"],
                AccountNumber = Config.AppSettings["UPSAccountNumber"],
                Password = Config.AppSettings["UPSPassword"],
                UserName = Config.AppSettings["UPSUserName"]
            });

            VeraCoreConnection veraCoreWMSConnection = new VeraCoreConnection
            {
                Username = ConfigurationManager.AppSettings["VeraCoreWMSAPIUsername"],
                Password = ConfigurationManager.AppSettings["VeraCoreWMSAPIPassword"],
                URL = ConfigurationManager.AppSettings["VeraCoreURL"],
                Timeout = Int32.Parse(ConfigurationManager.AppSettings["WebRequestTimeout"])
            };
            
            PrintJobSettings printJobSettings = new PrintJobSettings()
            {
                VeraCoreWMSConnection = veraCoreWMSConnection,
                Shippers = shippers,
                ShippingAccounts = shippingAccounts,
                SQLTimeout = Int32.Parse(ConfigurationManager.AppSettings["SQLTimeout"]),
                StartDate = ConfigurationManager.AppSettings.AllKeys.Contains("PrintJobStartDate") ? ConfigurationManager.AppSettings["PrintJobStartDate"] : null,
                EndDate = ConfigurationManager.AppSettings.AllKeys.Contains("PrintJobEndDate") ? ConfigurationManager.AppSettings["PrintJobEndDate"] : null,
                PrintFileOutputPath = ConfigurationManager.AppSettings.AllKeys.Contains("PrintFileOutputPath") ? ConfigurationManager.AppSettings["PrintFileOutputPath"] : null
            };

            return new PrintJob(clientId, settings, printJobSettings);
        }
    }
}
