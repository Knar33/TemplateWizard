﻿using IdComLog.Scheduling;
using IdComLog;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using IdComLog.$safeprojectname$;
using IdComLog.Shipping;
using IdComLog.Shipping.UPS;
using IdComLog.Shipping.RRD;
using IdComLog.VeraCore;
using System.Configuration;
using IdComLog.VeraCore.pmomsws;
using IdComLog.VeraCore.pmwarehouse;

namespace $ClientName$.$safeprojectname$
{
    public class ShipConfirmJobFactory : OmsJobFactory
    {
        protected override OmsJob CreateJob(OmsJobSettings settings)
        {
            Guid clientId = new Guid(Config.AppSettings["ClientId"]);

            List<IShipper> shippers = new List<IShipper>();
            UPSShipper upsShipper = new UPSShipper()
            {
                Url = Config.AppSettings["UPSWebServiceUrl"]
            };
            upsShipper.SetShippingAccount(new UPSShippingAccount()
            {
                AccessLicenseNumber = Config.AppSettings["UPSAccessLicenseNumber"],
                AccountNumber = Config.AppSettings["UPSAccountNumber"],
                Password = Config.AppSettings["UPSPassword"],
                UserName = Config.AppSettings["UPSUserName"]
            });

            VeraCoreConnection veraCoreWMSConnection = new VeraCoreConnection
            {
                Username = ConfigurationManager.AppSettings["VeraCoreWMSAPIUsername"],
                Password = ConfigurationManager.AppSettings["VeraCoreWMSAPIPassword"],
                URL = ConfigurationManager.AppSettings["VeraCoreURL"],
                Timeout = Int32.Parse(ConfigurationManager.AppSettings["WebRequestTimeout"])
            };

            OMSSoapClient omsClient = new OMSSoapClient(new System.ServiceModel.BasicHttpBinding(), new System.ServiceModel.EndpointAddress(string.Format("{0}/pmomsws/oms.asmx", ConfigurationManager.AppSettings["VeraCoreURL"])));
            omsClient.InnerChannel.OperationTimeout = new TimeSpan(0, 0, 0, 0, Int32.Parse(ConfigurationManager.AppSettings["WebRequestTimeout"]));
            IdComLog.VeraCore.pmomsws.AuthenticationHeader omsAuth = new IdComLog.VeraCore.pmomsws.AuthenticationHeader() { Username = ConfigurationManager.AppSettings["VeraCoreOMSAPIUsername"], Password = ConfigurationManager.AppSettings["VeraCoreOMSAPIPassword"] };

            ShippingSyncSoapClient WMSclient = new ShippingSyncSoapClient(new System.ServiceModel.BasicHttpBinding(), new System.ServiceModel.EndpointAddress(string.Format("{0}/pmwarehouse/services/ShippingSync.asmx", ConfigurationManager.AppSettings["VeraCoreURL"])));
            WMSclient.InnerChannel.OperationTimeout = new TimeSpan(0, 0, 0, 0, Int32.Parse(ConfigurationManager.AppSettings["WebRequestTimeout"]));
            IdComLog.VeraCore.pmwarehouse.AuthenticationHeader WMSAuth = new IdComLog.VeraCore.pmwarehouse.AuthenticationHeader() { Username = ConfigurationManager.AppSettings["VeraCoreWMSAPIUsername"], Password = ConfigurationManager.AppSettings["VeraCoreWMSAPIPassword"] };
            
            ShipConfirmJobSettings shipConfirmJobSettings = new ShipConfirmJobSettings()
            {
                VeraCoreWMSConnection = veraCoreWMSConnection,
                OMSClient = omsClient,
                OMSAuth = omsAuth,
                WMSClient = WMSclient,
                WMSAuth = WMSAuth,
                Shippers = shippers,
                SQLTimeout = Int32.Parse(ConfigurationManager.AppSettings["SQLTimeout"]),
                RRDAccount = null
            };

            return new ShipConfirmJob(clientId, settings, shipConfirmJobSettings);
        }
    }
}
