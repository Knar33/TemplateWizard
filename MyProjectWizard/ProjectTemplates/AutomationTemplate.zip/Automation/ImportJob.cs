﻿using IdComLog.$safeprojectname$;
using IdComLog.Scheduling;
using System;
using System.Threading.Tasks;

namespace $ClientName$.$safeprojectname$
{
    public class ImportJob : IdComLog.$safeprojectname$.ImportJob
    {
        public ImportJob(Guid clientid, OmsJobSettings settings, ImportJobSettings importJobSettings) : base(clientid, settings, importJobSettings)
        {
        }
    }
}
